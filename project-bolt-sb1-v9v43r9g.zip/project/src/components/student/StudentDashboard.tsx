import React, { useState, useEffect } from 'react';
import { Layout } from '../Layout';
import { BookOpen, Clock, Trophy, TrendingUp, Calendar, CheckCircle } from 'lucide-react';
import { Exam, ExamAttempt } from '../../types';

export const StudentDashboard: React.FC = () => {
  const [upcomingExams, setUpcomingExams] = useState<Exam[]>([]);
  const [recentAttempts, setRecentAttempts] = useState<ExamAttempt[]>([]);
  const [stats, setStats] = useState({
    totalExams: 0,
    completedExams: 0,
    averageScore: 0,
    upcomingExams: 0
  });

  useEffect(() => {
    // Mock data - in real app, this would come from API
    const mockUpcomingExams: Exam[] = [
      {
        id: '1',
        title: 'Data Structures Final',
        description: 'Comprehensive exam covering trees, graphs, and algorithms',
        courseId: '1',
        instructorId: '2',
        questions: [],
        duration: 120,
        totalPoints: 100,
        startDate: new Date(Date.now() + 86400000).toISOString(),
        endDate: new Date(Date.now() + 172800000).toISOString(),
        status: 'published',
        allowedAttempts: 1,
        shuffleQuestions: true,
        showResults: false
      },
      {
        id: '2',
        title: 'Web Development Quiz',
        description: 'Quick assessment on React and modern web technologies',
        courseId: '2',
        instructorId: '2',
        questions: [],
        duration: 30,
        totalPoints: 50,
        startDate: new Date(Date.now() + 259200000).toISOString(),
        endDate: new Date(Date.now() + 345600000).toISOString(),
        status: 'published',
        allowedAttempts: 2,
        shuffleQuestions: false,
        showResults: true
      }
    ];

    const mockRecentAttempts: ExamAttempt[] = [
      {
        id: '1',
        examId: '3',
        studentId: '1',
        answers: {},
        score: 85,
        startTime: new Date(Date.now() - 604800000).toISOString(),
        endTime: new Date(Date.now() - 600000000).toISOString(),
        status: 'graded',
        timeSpent: 3600
      },
      {
        id: '2',
        examId: '4',
        studentId: '1',
        answers: {},
        score: 92,
        startTime: new Date(Date.now() - 1209600000).toISOString(),
        endTime: new Date(Date.now() - 1205000000).toISOString(),
        status: 'graded',
        timeSpent: 2700
      }
    ];

    setUpcomingExams(mockUpcomingExams);
    setRecentAttempts(mockRecentAttempts);
    setStats({
      totalExams: 15,
      completedExams: 12,
      averageScore: 88.5,
      upcomingExams: mockUpcomingExams.length
    });
  }, []);

  const formatTimeRemaining = (date: string) => {
    const diff = new Date(date).getTime() - Date.now();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) {
      return `${days}d ${hours}h`;
    } else if (hours > 0) {
      return `${hours}h`;
    } else {
      return 'Soon';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Layout title="Student Dashboard">
      <div className="space-y-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Exams</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalExams}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-gray-900">{stats.completedExams}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Trophy className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Average Score</p>
                <p className="text-2xl font-bold text-gray-900">{stats.averageScore}%</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Upcoming</p>
                <p className="text-2xl font-bold text-gray-900">{stats.upcomingExams}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upcoming Exams */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                Upcoming Exams
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {upcomingExams.map((exam) => (
                <div key={exam.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{exam.title}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {formatTimeRemaining(exam.startDate)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{exam.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {exam.duration} min
                      </span>
                      <span>{exam.totalPoints} pts</span>
                    </div>
                    <button className="text-blue-600 hover:text-blue-800 font-medium">
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Attempts */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-green-600" />
                Recent Results
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {recentAttempts.map((attempt) => (
                <div key={attempt.id} className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">Database Systems Exam</h3>
                    <span className={`text-2xl font-bold ${getScoreColor(attempt.score || 0)}`}>
                      {attempt.score}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span>Completed {new Date(attempt.endTime!).toLocaleDateString()}</span>
                    <span>Time: {Math.floor(attempt.timeSpent / 60)}min</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};