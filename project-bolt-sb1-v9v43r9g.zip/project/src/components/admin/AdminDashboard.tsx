import React, { useState, useEffect } from 'react';
import { Layout } from '../Layout';
import { Users, BookOpen, BarChart3, Settings, Shield, Database, Activity } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [systemStats, setSystemStats] = useState({
    totalUsers: 0,
    totalInstructors: 0,
    totalStudents: 0,
    totalCourses: 0,
    totalExams: 0,
    activeExams: 0,
    systemHealth: 98,
    storageUsed: 67
  });

  const [recentActivity, setRecentActivity] = useState([
    { id: 1, type: 'user_created', message: 'New instructor John Smith registered', time: '5 minutes ago' },
    { id: 2, type: 'exam_created', message: 'Mathematics Final exam created by Dr. Johnson', time: '1 hour ago' },
    { id: 3, type: 'course_enrolled', message: '15 students enrolled in Web Development course', time: '2 hours ago' },
    { id: 4, type: 'system_update', message: 'System maintenance completed successfully', time: '1 day ago' }
  ]);

  useEffect(() => {
    // Mock data
    setSystemStats({
      totalUsers: 1247,
      totalInstructors: 89,
      totalStudents: 1158,
      totalCourses: 156,
      totalExams: 423,
      activeExams: 47,
      systemHealth: 98,
      storageUsed: 67
    });
  }, []);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user_created': return <Users className="w-4 h-4 text-green-600" />;
      case 'exam_created': return <BookOpen className="w-4 h-4 text-blue-600" />;
      case 'course_enrolled': return <BarChart3 className="w-4 h-4 text-purple-600" />;
      case 'system_update': return <Settings className="w-4 h-4 text-gray-600" />;
      default: return <Activity className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <Layout title="Admin Dashboard">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900">System Overview</h2>
          <p className="text-gray-600">Monitor and manage the entire e-exam platform</p>
        </div>

        {/* System Health Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-2xl font-bold text-gray-900">{systemStats.totalUsers.toLocaleString()}</p>
                <p className="text-xs text-gray-500">
                  {systemStats.totalInstructors} instructors, {systemStats.totalStudents} students
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <BookOpen className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Content</p>
                <p className="text-2xl font-bold text-gray-900">{systemStats.totalCourses}</p>
                <p className="text-xs text-gray-500">{systemStats.totalExams} exams total</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Activity className="w-6 h-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">System Health</p>
                <p className="text-2xl font-bold text-gray-900">{systemStats.systemHealth}%</p>
                <p className="text-xs text-green-600">Excellent</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Database className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Storage</p>
                <p className="text-2xl font-bold text-gray-900">{systemStats.storageUsed}%</p>
                <p className="text-xs text-gray-500">Used of 500GB</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <Settings className="w-5 h-5 mr-2 text-gray-600" />
                Quick Actions
              </h2>
            </div>
            <div className="p-6 space-y-4">
              <button className="w-full flex items-center justify-between p-3 text-left border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center">
                  <Users className="w-5 h-5 text-blue-600 mr-3" />
                  <span className="font-medium text-gray-900">Manage Users</span>
                </div>
              </button>
              
              <button className="w-full flex items-center justify-between p-3 text-left border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center">
                  <BookOpen className="w-5 h-5 text-green-600 mr-3" />
                  <span className="font-medium text-gray-900">Course Management</span>
                </div>
              </button>
              
              <button className="w-full flex items-center justify-between p-3 text-left border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center">
                  <Shield className="w-5 h-5 text-purple-600 mr-3" />
                  <span className="font-medium text-gray-900">Security Settings</span>
                </div>
              </button>
              
              <button className="w-full flex items-center justify-between p-3 text-left border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center">
                  <BarChart3 className="w-5 h-5 text-yellow-600 mr-3" />
                  <span className="font-medium text-gray-900">System Reports</span>
                </div>
              </button>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <Activity className="w-5 h-5 mr-2 text-green-600" />
                Recent Activity
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="p-6 flex items-start space-x-4">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* System Metrics */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">System Metrics</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{systemStats.activeExams}</div>
                <div className="text-sm text-gray-600">Active Exams</div>
                <div className="text-xs text-green-600 mt-1">↑ 12% from last week</div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">99.2%</div>
                <div className="text-sm text-gray-600">Uptime</div>
                <div className="text-xs text-green-600 mt-1">↑ 0.3% from last month</div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">1,340</div>
                <div className="text-sm text-gray-600">Daily Active Users</div>
                <div className="text-xs text-green-600 mt-1">↑ 8% from yesterday</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};