import React, { useState, useEffect } from 'react';
import { Layout } from '../Layout';
import { Clock, Save, CheckCircle, AlertTriangle, ChevronLeft, ChevronRight } from 'lucide-react';
import { Question, Exam } from '../../types';

export const ExamInterface: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [timeRemaining, setTimeRemaining] = useState(7200); // 2 hours in seconds
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  const mockExam: Exam = {
    id: '1',
    title: 'Data Structures Final Examination',
    description: 'Comprehensive exam covering trees, graphs, sorting algorithms, and complexity analysis',
    courseId: '1',
    instructorId: '2',
    duration: 120,
    totalPoints: 100,
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 7200000).toISOString(),
    status: 'published',
    allowedAttempts: 1,
    shuffleQuestions: true,
    showResults: false,
    questions: [
      {
        id: '1',
        type: 'multiple-choice',
        question: 'What is the time complexity of inserting an element into a balanced binary search tree?',
        options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
        correctAnswer: 1,
        points: 5,
        category: 'Data Structures',
        difficulty: 'medium'
      },
      {
        id: '2',
        type: 'multiple-choice',
        question: 'Which sorting algorithm has the best average-case time complexity?',
        options: ['Bubble Sort', 'Quick Sort', 'Merge Sort', 'Selection Sort'],
        correctAnswer: 2,
        points: 5,
        category: 'Algorithms',
        difficulty: 'medium'
      },
      {
        id: '3',
        type: 'short-answer',
        question: 'Explain the difference between a stack and a queue data structure.',
        points: 10,
        category: 'Data Structures',
        difficulty: 'easy'
      },
      {
        id: '4',
        type: 'essay',
        question: 'Discuss the advantages and disadvantages of using a hash table versus a binary search tree for implementing a dictionary/map data structure. Include considerations for time complexity, space complexity, and practical use cases.',
        points: 15,
        category: 'Data Structures',
        difficulty: 'hard'
      }
    ]
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      autoSave();
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [answers]);

  const autoSave = async () => {
    setAutoSaveStatus('saving');
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAutoSaveStatus('saved');
    } catch {
      setAutoSaveStatus('error');
    }
  };

  const handleAutoSubmit = () => {
    // Auto-submit when time runs out
    console.log('Auto-submitting exam...');
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: string, answer: string | number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const getQuestionProgress = () => {
    const answered = Object.keys(answers).length;
    const total = mockExam.questions.length;
    return { answered, total, percentage: (answered / total) * 100 };
  };

  const renderQuestion = (question: Question) => {
    const currentAnswer = answers[question.id];

    switch (question.type) {
      case 'multiple-choice':
        return (
          <div className="space-y-4">
            {question.options?.map((option, index) => (
              <label key={index} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                <input
                  type="radio"
                  name={`question-${question.id}`}
                  value={index}
                  checked={currentAnswer === index}
                  onChange={(e) => handleAnswerChange(question.id, parseInt(e.target.value))}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span className="text-gray-900">{option}</span>
              </label>
            ))}
          </div>
        );

      case 'true-false':
        return (
          <div className="space-y-4">
            <label className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
              <input
                type="radio"
                name={`question-${question.id}`}
                value="true"
                checked={currentAnswer === 'true'}
                onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="text-gray-900">True</span>
            </label>
            <label className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
              <input
                type="radio"
                name={`question-${question.id}`}
                value="false"
                checked={currentAnswer === 'false'}
                onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="text-gray-900">False</span>
            </label>
          </div>
        );

      case 'short-answer':
        return (
          <textarea
            value={currentAnswer || ''}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            className="w-full h-24 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            placeholder="Type your answer here..."
          />
        );

      case 'essay':
        return (
          <textarea
            value={currentAnswer || ''}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            className="w-full h-48 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            placeholder="Write your essay answer here..."
          />
        );

      default:
        return null;
    }
  };

  const progress = getQuestionProgress();

  return (
    <Layout title="Taking Exam">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Exam Header */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{mockExam.title}</h1>
              <p className="text-gray-600 mt-1">{mockExam.description}</p>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="flex items-center text-2xl font-bold text-gray-900">
                  <Clock className="w-6 h-6 mr-2 text-blue-600" />
                  {formatTime(timeRemaining)}
                </div>
                <p className="text-sm text-gray-600">Time Remaining</p>
              </div>
              <div className="text-center">
                <div className="flex items-center text-lg font-semibold">
                  {autoSaveStatus === 'saved' && <CheckCircle className="w-5 h-5 text-green-600 mr-2" />}
                  {autoSaveStatus === 'saving' && <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2" />}
                  {autoSaveStatus === 'error' && <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />}
                  <span className={
                    autoSaveStatus === 'saved' ? 'text-green-600' :
                    autoSaveStatus === 'saving' ? 'text-blue-600' : 'text-red-600'
                  }>
                    {autoSaveStatus === 'saved' ? 'Saved' :
                     autoSaveStatus === 'saving' ? 'Saving...' : 'Error'}
                  </span>
                </div>
                <p className="text-sm text-gray-600">Auto-save</p>
              </div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm text-gray-600">{progress.answered} of {progress.total} questions answered</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                Question {currentQuestion + 1} of {mockExam.questions.length}
              </span>
              <span className="text-sm text-gray-600">
                {mockExam.questions[currentQuestion].points} points
              </span>
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              {mockExam.questions[currentQuestion].question}
            </h2>
          </div>

          {renderQuestion(mockExam.questions[currentQuestion])}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
            disabled={currentQuestion === 0}
            className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </button>

          <div className="flex space-x-4">
            <button
              onClick={autoSave}
              className="flex items-center px-4 py-2 text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Progress
            </button>

            {currentQuestion === mockExam.questions.length - 1 ? (
              <button
                onClick={() => setShowSubmitConfirm(true)}
                className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
              >
                Submit Exam
              </button>
            ) : (
              <button
                onClick={() => setCurrentQuestion(prev => Math.min(mockExam.questions.length - 1, prev + 1))}
                className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </button>
            )}
          </div>
        </div>

        {/* Submit Confirmation Modal */}
        {showSubmitConfirm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4 p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Submit Exam?</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to submit your exam? You have answered {progress.answered} out of {progress.total} questions.
                This action cannot be undone.
              </p>
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowSubmitConfirm(false)}
                  className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    // Handle exam submission
                    console.log('Submitting exam...');
                    setShowSubmitConfirm(false);
                  }}
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};