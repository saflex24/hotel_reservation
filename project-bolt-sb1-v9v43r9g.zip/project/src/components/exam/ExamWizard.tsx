import React, { useState } from 'react';
import { Layout } from '../Layout';
import { Plus, X, Save, Eye, Clock, Settings } from 'lucide-react';
import { Question, Exam } from '../../types';

export const ExamWizard: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [examData, setExamData] = useState<Partial<Exam>>({
    title: '',
    description: '',
    duration: 60,
    totalPoints: 0,
    allowedAttempts: 1,
    shuffleQuestions: false,
    showResults: true,
    questions: []
  });

  const steps = [
    { id: 0, title: 'Basic Information', icon: Settings },
    { id: 1, title: 'Add Questions', icon: Plus },
    { id: 2, title: 'Settings', icon: Clock },
    { id: 3, title: 'Review', icon: Eye }
  ];

  const questionTypes = [
    { value: 'multiple-choice', label: 'Multiple Choice' },
    { value: 'true-false', label: 'True/False' },
    { value: 'short-answer', label: 'Short Answer' },
    { value: 'essay', label: 'Essay' }
  ];

  const [newQuestion, setNewQuestion] = useState<Partial<Question>>({
    type: 'multiple-choice',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    points: 5,
    category: '',
    difficulty: 'medium'
  });

  const addOption = () => {
    if (newQuestion.options && newQuestion.options.length < 6) {
      setNewQuestion(prev => ({
        ...prev,
        options: [...(prev.options || []), '']
      }));
    }
  };

  const removeOption = (index: number) => {
    setNewQuestion(prev => ({
      ...prev,
      options: prev.options?.filter((_, i) => i !== index)
    }));
  };

  const updateOption = (index: number, value: string) => {
    setNewQuestion(prev => ({
      ...prev,
      options: prev.options?.map((opt, i) => i === index ? value : opt)
    }));
  };

  const addQuestion = () => {
    if (newQuestion.question && newQuestion.points) {
      const question: Question = {
        id: Date.now().toString(),
        type: newQuestion.type as Question['type'],
        question: newQuestion.question,
        options: newQuestion.type === 'multiple-choice' ? newQuestion.options : undefined,
        correctAnswer: newQuestion.correctAnswer,
        points: newQuestion.points,
        category: newQuestion.category || 'General',
        difficulty: newQuestion.difficulty as Question['difficulty'],
        explanation: newQuestion.explanation
      };

      setExamData(prev => ({
        ...prev,
        questions: [...(prev.questions || []), question],
        totalPoints: (prev.totalPoints || 0) + question.points
      }));

      setNewQuestion({
        type: 'multiple-choice',
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
        points: 5,
        category: '',
        difficulty: 'medium'
      });
    }
  };

  const removeQuestion = (index: number) => {
    const questions = examData.questions || [];
    const removedQuestion = questions[index];
    
    setExamData(prev => ({
      ...prev,
      questions: questions.filter((_, i) => i !== index),
      totalPoints: (prev.totalPoints || 0) - removedQuestion.points
    }));
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Basic Information</h2>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Exam Title *
              </label>
              <input
                type="text"
                value={examData.title || ''}
                onChange={(e) => setExamData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter exam title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={examData.description || ''}
                onChange={(e) => setExamData(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Provide a brief description of the exam"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Course
                </label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>Data Structures & Algorithms</option>
                  <option>Web Development</option>
                  <option>Database Systems</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration (minutes) *
                </label>
                <input
                  type="number"
                  value={examData.duration || ''}
                  onChange={(e) => setExamData(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="1"
                />
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Add Questions</h2>
              <div className="text-sm text-gray-600">
                Total Points: {examData.totalPoints}
              </div>
            </div>

            {/* Question Form */}
            <div className="bg-gray-50 rounded-xl p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Question Type
                  </label>
                  <select
                    value={newQuestion.type}
                    onChange={(e) => setNewQuestion(prev => ({ 
                      ...prev, 
                      type: e.target.value as Question['type'],
                      options: e.target.value === 'multiple-choice' ? ['', '', '', ''] : undefined
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {questionTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Points
                  </label>
                  <input
                    type="number"
                    value={newQuestion.points || ''}
                    onChange={(e) => setNewQuestion(prev => ({ ...prev, points: parseInt(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Question Text *
                </label>
                <textarea
                  value={newQuestion.question || ''}
                  onChange={(e) => setNewQuestion(prev => ({ ...prev, question: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  placeholder="Enter your question"
                />
              </div>

              {newQuestion.type === 'multiple-choice' && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <label className="block text-sm font-medium text-gray-700">
                      Answer Options
                    </label>
                    <button
                      type="button"
                      onClick={addOption}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      Add Option
                    </button>
                  </div>
                  <div className="space-y-3">
                    {newQuestion.options?.map((option, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <input
                          type="radio"
                          name="correct-answer"
                          checked={newQuestion.correctAnswer === index}
                          onChange={() => setNewQuestion(prev => ({ ...prev, correctAnswer: index }))}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => updateOption(index, e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder={`Option ${index + 1}`}
                        />
                        {newQuestion.options!.length > 2 && (
                          <button
                            type="button"
                            onClick={() => removeOption(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Category
                  </label>
                  <input
                    type="text"
                    value={newQuestion.category || ''}
                    onChange={(e) => setNewQuestion(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Data Structures"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Difficulty
                  </label>
                  <select
                    value={newQuestion.difficulty}
                    onChange={(e) => setNewQuestion(prev => ({ ...prev, difficulty: e.target.value as Question['difficulty'] }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard</option>
                  </select>
                </div>
              </div>

              <button
                onClick={addQuestion}
                className="w-full flex items-center justify-center px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </button>
            </div>

            {/* Questions List */}
            {examData.questions && examData.questions.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Questions ({examData.questions.length})
                </h3>
                {examData.questions.map((question, index) => (
                  <div key={question.id} className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {question.type.replace('-', ' ')}
                          </span>
                          <span className="text-sm text-gray-500">{question.points} pts</span>
                        </div>
                        <p className="text-gray-900 font-medium">{question.question}</p>
                        {question.options && (
                          <ul className="mt-2 text-sm text-gray-600 space-y-1">
                            {question.options.map((option, optIndex) => (
                              <li key={optIndex} className={optIndex === question.correctAnswer ? 'text-green-600 font-medium' : ''}>
                                {optIndex + 1}. {option}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                      <button
                        onClick={() => removeQuestion(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Exam Settings</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Allowed Attempts
                </label>
                <input
                  type="number"
                  value={examData.allowedAttempts || 1}
                  onChange={(e) => setExamData(prev => ({ ...prev, allowedAttempts: parseInt(e.target.value) }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="1"
                  max="10"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date & Time
                </label>
                <input
                  type="datetime-local"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="shuffleQuestions"
                  checked={examData.shuffleQuestions || false}
                  onChange={(e) => setExamData(prev => ({ ...prev, shuffleQuestions: e.target.checked }))}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="shuffleQuestions" className="ml-2 block text-sm text-gray-900">
                  Shuffle question order for each student
                </label>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="showResults"
                  checked={examData.showResults || false}
                  onChange={(e) => setExamData(prev => ({ ...prev, showResults: e.target.checked }))}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="showResults" className="ml-2 block text-sm text-gray-900">
                  Show results immediately after submission
                </label>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="preventCopyPaste"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="preventCopyPaste" className="ml-2 block text-sm text-gray-900">
                  Prevent copy and paste
                </label>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="lockdownBrowser"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="lockdownBrowser" className="ml-2 block text-sm text-gray-900">
                  Require lockdown browser
                </label>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Review & Publish</h2>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-4">Exam Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Title:</span>
                  <span className="ml-2 text-gray-900">{examData.title}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Duration:</span>
                  <span className="ml-2 text-gray-900">{examData.duration} minutes</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Questions:</span>
                  <span className="ml-2 text-gray-900">{examData.questions?.length || 0}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Total Points:</span>
                  <span className="ml-2 text-gray-900">{examData.totalPoints}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Attempts:</span>
                  <span className="ml-2 text-gray-900">{examData.allowedAttempts}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Shuffle Questions:</span>
                  <span className="ml-2 text-gray-900">{examData.shuffleQuestions ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <button className="flex-1 px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors">
                Save as Draft
              </button>
              <button className="flex-1 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors">
                Publish Exam
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Layout title="Create Exam">
      <div className="max-w-4xl mx-auto">
        {/* Progress Steps */}
        <div className="mb-8">
          <nav aria-label="Progress">
            <ol className="flex items-center">
              {steps.map((step, stepIdx) => (
                <li key={step.id} className={`${stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20' : ''} relative`}>
                  {currentStep > step.id ? (
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                      <div className="h-0.5 w-full bg-blue-600" />
                    </div>
                  ) : currentStep === step.id ? (
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                      <div className="h-0.5 w-full bg-gray-200" />
                    </div>
                  ) : (
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                      <div className="h-0.5 w-full bg-gray-200" />
                    </div>
                  )}
                  
                  <div className={`relative w-8 h-8 flex items-center justify-center rounded-full ${
                    currentStep > step.id
                      ? 'bg-blue-600'
                      : currentStep === step.id
                      ? 'bg-white border-2 border-blue-600'
                      : 'bg-white border-2 border-gray-300'
                  }`}>
                    <step.icon className={`w-4 h-4 ${
                      currentStep > step.id
                        ? 'text-white'
                        : currentStep === step.id
                        ? 'text-blue-600'
                        : 'text-gray-400'
                    }`} />
                  </div>
                  
                  <div className="mt-2">
                    <span className={`text-xs font-medium ${
                      currentStep >= step.id ? 'text-blue-600' : 'text-gray-500'
                    }`}>
                      {step.title}
                    </span>
                  </div>
                </li>
              ))}
            </ol>
          </nav>
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          {renderStepContent()}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-8">
          <button
            onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
            disabled={currentStep === 0}
            className="px-6 py-3 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Previous
          </button>

          <div className="flex space-x-4">
            <button className="flex items-center px-4 py-3 text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors">
              <Save className="w-4 h-4 mr-2" />
              Save Progress
            </button>

            {currentStep < steps.length - 1 ? (
              <button
                onClick={() => setCurrentStep(prev => Math.min(steps.length - 1, prev + 1))}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
              >
                Next
              </button>
            ) : (
              <button className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors">
                Finish
              </button>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};