import React, { useState, useEffect } from 'react';
import { Layout } from '../Layout';
import { Plus, BookOpen, Users, BarChart3, Clock, TrendingUp } from 'lucide-react';
import { Exam, Course, Analytics } from '../../types';

export const InstructorDashboard: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [analytics, setAnalytics] = useState<Analytics[]>([]);
  const [stats, setStats] = useState({
    totalCourses: 0,
    totalStudents: 0,
    activeExams: 0,
    averageScore: 0
  });

  useEffect(() => {
    // Mock data
    const mockCourses: Course[] = [
      {
        id: '1',
        name: 'Data Structures & Algorithms',
        description: 'Advanced programming concepts and problem-solving techniques',
        instructorId: '2',
        students: ['1', '3', '4', '5'],
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Web Development',
        description: 'Modern web technologies including React, Node.js, and databases',
        instructorId: '2',
        students: ['1', '6', '7'],
        createdAt: new Date().toISOString()
      }
    ];

    const mockExams: Exam[] = [
      {
        id: '1',
        title: 'Data Structures Final',
        description: 'Comprehensive final exam',
        courseId: '1',
        instructorId: '2',
        questions: [],
        duration: 120,
        totalPoints: 100,
        startDate: new Date(Date.now() + 86400000).toISOString(),
        endDate: new Date(Date.now() + 172800000).toISOString(),
        status: 'published',
        allowedAttempts: 1,
        shuffleQuestions: true,
        showResults: false
      },
      {
        id: '2',
        title: 'React Components Quiz',
        description: 'Quick assessment on React fundamentals',
        courseId: '2',
        instructorId: '2',
        questions: [],
        duration: 30,
        totalPoints: 50,
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 86400000).toISOString(),
        status: 'published',
        allowedAttempts: 2,
        shuffleQuestions: false,
        showResults: true
      }
    ];

    setCourses(mockCourses);
    setExams(mockExams);
    setStats({
      totalCourses: mockCourses.length,
      totalStudents: mockCourses.reduce((sum, course) => sum + course.students.length, 0),
      activeExams: mockExams.filter(exam => exam.status === 'published').length,
      averageScore: 87.3
    });
  }, []);

  return (
    <Layout title="Instructor Dashboard">
      <div className="space-y-8">
        {/* Action Bar */}
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Welcome back, Dr. Johnson</h2>
            <p className="text-gray-600">Manage your courses and track student progress</p>
          </div>
          <div className="flex space-x-3">
            <button className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors">
              <Plus className="w-4 h-4 mr-2" />
              Create Exam
            </button>
            <button className="inline-flex items-center px-4 py-2 bg-white hover:bg-gray-50 text-gray-700 font-medium rounded-lg border border-gray-300 transition-colors">
              <Plus className="w-4 h-4 mr-2" />
              Add Course
            </button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Courses</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalCourses}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Students</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalStudents}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Exams</p>
                <p className="text-2xl font-bold text-gray-900">{stats.activeExams}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Avg Score</p>
                <p className="text-2xl font-bold text-gray-900">{stats.averageScore}%</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Courses */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-blue-600" />
                My Courses
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {courses.map((course) => (
                <div key={course.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{course.name}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {course.students.length} students
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{course.description}</p>
                  <div className="flex space-x-3">
                    <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                      Manage
                    </button>
                    <button className="text-gray-500 hover:text-gray-700 text-sm font-medium">
                      View Analytics
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Exams */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-green-600" />
                Recent Exams
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {exams.map((exam) => (
                <div key={exam.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{exam.title}</h3>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      exam.status === 'published' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {exam.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {exam.duration} min
                      </span>
                      <span>{exam.totalPoints} pts</span>
                    </div>
                    <div className="flex space-x-3">
                      <button className="text-blue-600 hover:text-blue-800 font-medium">
                        Edit
                      </button>
                      <button className="text-green-600 hover:text-green-800 font-medium">
                        Results
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};