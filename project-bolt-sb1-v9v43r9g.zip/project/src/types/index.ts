export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'instructor' | 'admin';
  avatar?: string;
  createdAt: string;
}

export interface Course {
  id: string;
  name: string;
  description: string;
  instructorId: string;
  students: string[];
  createdAt: string;
}

export interface Question {
  id: string;
  type: 'multiple-choice' | 'true-false' | 'short-answer' | 'essay';
  question: string;
  options?: string[];
  correctAnswer?: string | number;
  points: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation?: string;
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  courseId: string;
  instructorId: string;
  questions: Question[];
  duration: number; // in minutes
  totalPoints: number;
  startDate: string;
  endDate: string;
  status: 'draft' | 'published' | 'archived';
  allowedAttempts: number;
  shuffleQuestions: boolean;
  showResults: boolean;
}

export interface ExamAttempt {
  id: string;
  examId: string;
  studentId: string;
  answers: Record<string, string | number>;
  score?: number;
  startTime: string;
  endTime?: string;
  status: 'in-progress' | 'submitted' | 'graded';
  timeSpent: number; // in seconds
}

export interface Analytics {
  examId: string;
  totalAttempts: number;
  averageScore: number;
  completionRate: number;
  questionAnalytics: QuestionAnalytics[];
}

export interface QuestionAnalytics {
  questionId: string;
  correctAnswers: number;
  totalAnswers: number;
  averageTime: number;
}