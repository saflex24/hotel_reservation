import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthProvider = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('examUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Mock authentication - in real app, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Demo users
      const demoUsers: User[] = [
        { id: '1', email: 'student@demo.com', name: 'John Student', role: 'student', createdAt: new Date().toISOString() },
        { id: '2', email: 'instructor@demo.com', name: 'Dr. Sarah Johnson', role: 'instructor', createdAt: new Date().toISOString() },
        { id: '3', email: 'admin@demo.com', name: 'Admin User', role: 'admin', createdAt: new Date().toISOString() }
      ];

      const foundUser = demoUsers.find(u => u.email === email);
      if (foundUser && password === 'demo123') {
        setUser(foundUser);
        localStorage.setItem('examUser', JSON.stringify(foundUser));
      } else {
        throw new Error('Invalid credentials');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('examUser');
  };

  return {
    user,
    login,
    logout,
    isLoading
  };
};

export { AuthContext };