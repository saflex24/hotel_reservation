import React from 'react';
import { useAuth } from './hooks/useAuth';
import { AuthProvider } from './components/AuthProvider';
import { Login } from './components/Login';
import { StudentDashboard } from './components/student/StudentDashboard';
import { InstructorDashboard } from './components/instructor/InstructorDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ExamInterface } from './components/exam/ExamInterface';
import { ExamWizard } from './components/exam/ExamWizard';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  // Simple routing based on URL hash for demo purposes
  const currentPage = window.location.hash.slice(1) || 'dashboard';

  // Route to appropriate page based on user role and current page
  switch (currentPage) {
    case 'exam':
      return <ExamInterface />;
    case 'create-exam':
      return user.role === 'instructor' ? <ExamWizard /> : <InstructorDashboard />;
    case 'dashboard':
    default:
      switch (user.role) {
        case 'student':
          return <StudentDashboard />;
        case 'instructor':
          return <InstructorDashboard />;
        case 'admin':
          return <AdminDashboard />;
        default:
          return <StudentDashboard />;
      }
  }
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;